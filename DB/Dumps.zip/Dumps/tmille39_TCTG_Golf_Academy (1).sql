-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 31, 2024 at 07:38 PM
-- Server version: 5.7.23-23
-- PHP Version: 8.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tmille39_TCTG_Golf_Academy`
--

-- --------------------------------------------------------

--
-- Table structure for table `Player`
--

CREATE TABLE `Player` (
  `dbplayerid` int(11) NOT NULL COMMENT 'Primary Key',
  `dbplayerfirstname` varchar(25) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Player''s First Name',
  `dbplayerlastname` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Player''s Last Name',
  `dbplayeremailaddress` varchar(150) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Player''s Email Address',
  `dbplayerphonenumber` varchar(14) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Player''s Phone Number\r\n[Format => (XXX)-XXX-XXXX]	',
  `dbplayerpassword` varchar(150) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Player''s Password',
  `dbrewardid` int(11) NOT NULL COMMENT '	Foreign key that comes from Reward'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Player`
--

INSERT INTO `Player` (`dbplayerid`, `dbplayerfirstname`, `dbplayerlastname`, `dbplayeremailaddress`, `dbplayerphonenumber`, `dbplayerpassword`, `dbrewardid`) VALUES
(1, 'Johnny', 'Bravo', 'Bravo@email.com', '(843)-555-5555', '$2b$12$..8XPoWnpHmDycowFngoSufPCthSrxBiDHniVvZrP/oSAd/Ga1MQ.', 1),
(2, 'Jenny', 'Martin', 'Martin@email.com', '(843)-555-5555', '$2b$12$UluD6ytP8mjdGs9iuxIic.OJOxRRBPNpJe7tN2SV7u6Qozkzrmihy', 4),
(3, 'Ritu', 'Alexandros', 'Alexandros@email.com', '(712)-431-2315', '$2b$12$xJVj9TWaZwl.nVlcBZRUkOHYYtO35EIZxHgpIdoVuhm2yq8ISSWwu', 2),
(4, 'James', 'Martin', 'JM@email.com', '(742)-553-5555', '$2b$12$WKaoQoIl8nOGDKsVcpEYt.IJLEUe1gnc1zel6tWFtRK9Vv4eOEYmK', 3),
(5, 'ddd', 'ddd', 'd@d.com', '(843)-111-1111', '$2b$12$b/WTv20i4FPpV9Gk7u0DXeCkF8Lox1XEJhOos0EmjdMT87uYRgZ6m', 1),
(6, 'Player', 'Player', 'Player@Player.com', '(123)-456-7890', '$2b$12$X0t802/UfLDtosNPssVfMewHtX0de8oqNYmFd/ieBVPmCB45o3W9G', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Product`
--

CREATE TABLE `Product` (
  `dbproductid` int(11) NOT NULL COMMENT 'Primary Key',
  `dbproductname` varchar(75) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Product''s Name',
  `dbproductdescription` mediumtext COLLATE utf8_unicode_ci NOT NULL COMMENT 'Description of Product',
  `dbproductprice` decimal(6,2) NOT NULL COMMENT 'Product''s Price',
  `dbproductquantity` int(5) NOT NULL COMMENT 'Number of Product in Golf Course'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Product`
--

INSERT INTO `Product` (`dbproductid`, `dbproductname`, `dbproductdescription`, `dbproductprice`, `dbproductquantity`) VALUES
(1, 'Tee Shirts', 'This Shirt is a XL. That has a tee and a golf ball on it!', 25.00, 25),
(2, 'Golf Ball', '3 Golf balls are included in one Package (1 Unit = 3 Golf Balls)!', 20.00, 75),
(3, 'Golf Club Starter Package', 'This Starter Package includes Top Grade Golf Club Items!', 120.00, 18),
(4, 'Candy Bar', 'A delicious Chocolate Bar!', 3.99, 89),
(5, 'd', 'd', 1.00, 1),
(6, 'dfdfd', 'd', 3.00, 3),
(7, 'a', 'a', 2.00, 3);

-- --------------------------------------------------------

--
-- Table structure for table `Purchase`
--

CREATE TABLE `Purchase` (
  `dbpurchaseid` int(11) NOT NULL COMMENT 'Primary Key',
  `dbuserid` int(11) NOT NULL COMMENT 'Foreign key that comes from User \r\n(Can be null since purchase can be made online)',
  `dbplayerid` int(11) NOT NULL COMMENT 'Foreign key that comes from Player',
  `dbpurchasedatetime` datetime NOT NULL COMMENT 'Purchase Date and Time'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Purchase`
--

INSERT INTO `Purchase` (`dbpurchaseid`, `dbuserid`, `dbplayerid`, `dbpurchasedatetime`) VALUES
(2, 10, 3, '2024-03-22 10:00:00'),
(3, 1, 2, '2024-03-21 10:26:00'),
(4, 2, 1, '2024-03-21 22:05:22'),
(5, 11, 4, '2024-03-25 13:33:58');

-- --------------------------------------------------------

--
-- Table structure for table `PurchaseDetail`
--

CREATE TABLE `PurchaseDetail` (
  `dbpurchasedetailid` int(11) NOT NULL COMMENT 'Primary Key',
  `dbpurchaseid` int(11) NOT NULL COMMENT 'Foreign key that comes from Purchase',
  `dbproductid` int(11) NOT NULL COMMENT 'Foreign key that comes from Product',
  `dbpurchasedetailquantity` int(5) NOT NULL COMMENT 'Number of product''s purchased',
  `dbpurchasedetailpricetotal` decimal(6,2) NOT NULL COMMENT 'Total from purchase'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `PurchaseDetail`
--

INSERT INTO `PurchaseDetail` (`dbpurchasedetailid`, `dbpurchaseid`, `dbproductid`, `dbpurchasedetailquantity`, `dbpurchasedetailpricetotal`) VALUES
(2, 2, 1, 2, 20.00),
(3, 3, 1, 2, 75.00),
(4, 4, 1, 1, 30.00),
(5, 5, 4, 2, 8.99);

-- --------------------------------------------------------

--
-- Table structure for table `Reservation`
--

CREATE TABLE `Reservation` (
  `dbreservationid` int(11) NOT NULL COMMENT 'Primary Key',
  `dbuserid` int(11) NOT NULL COMMENT 'Foreign key that comes from User\r\n(Can be null due to since the reservation can be made online by player)',
  `dbplayerid` int(11) NOT NULL COMMENT 'Foreign key that comes from Player',
  `dbnumofplayers` int(2) NOT NULL,
  `dbreservationdatetime` datetime NOT NULL COMMENT 'Reservation Date and Time',
  `dbreservationconfimed` tinyint(1) NOT NULL COMMENT 'Reservation that is confirmed by User (This is for reservations that are made online to check if there is a spot available)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Reservation`
--

INSERT INTO `Reservation` (`dbreservationid`, `dbuserid`, `dbplayerid`, `dbnumofplayers`, `dbreservationdatetime`, `dbreservationconfimed`) VALUES
(2, 11, 3, 0, '2024-03-21 11:40:00', 1),
(3, 2, 2, 0, '2024-03-22 14:08:00', 0),
(4, 1, 1, 0, '2024-03-21 08:16:00', 0),
(8, 1, 1, 0, '2024-03-16 08:00:00', 0),
(12, 12, 3, 0, '2024-03-24 08:24:00', 0),
(13, 12, 3, 0, '2024-03-25 15:40:00', 0),
(14, 11, 4, 0, '2024-03-25 13:24:00', 0),
(15, 13, 2, 0, '2024-03-25 08:32:00', 0),
(16, 11, 4, 0, '2024-03-12 08:56:00', 0),
(17, 2, 5, 0, '2024-03-27 10:08:00', 1),
(19, 10, 4, 3, '2024-03-31 08:08:00', 1),
(20, 0, 1, 4, '2024-03-31 09:24:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Reward`
--

CREATE TABLE `Reward` (
  `dbrewardid` int(11) NOT NULL COMMENT 'Primary Key',
  `dbrewardname` varchar(25) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Reward Name (Type)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Reward`
--

INSERT INTO `Reward` (`dbrewardid`, `dbrewardname`) VALUES
(1, 'Diamond'),
(2, 'Platinum'),
(3, 'Gold'),
(4, 'Silver');

-- --------------------------------------------------------

--
-- Table structure for table `Role`
--

CREATE TABLE `Role` (
  `dbroleid` int(11) NOT NULL COMMENT 'Primary Key',
  `dbrolename` varchar(25) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Role Name (Type)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Role`
--

INSERT INTO `Role` (`dbroleid`, `dbrolename`) VALUES
(1, 'Admin'),
(2, 'Manager'),
(3, 'Employee');

-- --------------------------------------------------------

--
-- Table structure for table `Status`
--

CREATE TABLE `Status` (
  `dbstatusid` int(11) NOT NULL COMMENT 'Primary Key',
  `dbpurchasedetailid` int(11) NOT NULL COMMENT 'Foreign key that comes from Purchase Detail',
  `dbstatusname` mediumtext COLLATE utf8_unicode_ci NOT NULL COMMENT 'Text to show the current status of the purchase (Complete, Processing, Shipping, etc.)',
  `dbstatusdatetime` datetime NOT NULL COMMENT 'Show the last time the status was last updated'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Status`
--

INSERT INTO `Status` (`dbstatusid`, `dbpurchasedetailid`, `dbstatusname`, `dbstatusdatetime`) VALUES
(1, 2, 'Complete', '2024-03-23 02:14:10'),
(2, 3, 'Back-Order', '2024-03-21 10:26:35'),
(3, 4, 'Complete', '2024-03-21 22:05:22'),
(4, 5, 'Complete', '2024-03-25 13:33:58');

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `dbuserid` int(11) NOT NULL COMMENT 'Primary Key',
  `dbuserfirstname` varchar(25) COLLATE utf8_unicode_ci NOT NULL COMMENT 'User''s First Name',
  `dbuserlastname` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'User''s Last Name',
  `dbuseremailaddress` varchar(150) COLLATE utf8_unicode_ci NOT NULL COMMENT 'User''s Email Address',
  `dbuserphonenumber` varchar(14) COLLATE utf8_unicode_ci NOT NULL COMMENT 'User''s Phone Number [Format => (XXX)-XXX-XXXX]',
  `dbuserhiredate` date NOT NULL COMMENT 'User''s Hire Date',
  `dbuserpassword` varchar(150) COLLATE utf8_unicode_ci NOT NULL COMMENT 'User''s Password',
  `dbuseraccess` tinyint(1) NOT NULL COMMENT 'User''s Access (If allowed to login)',
  `dbroleid` int(11) NOT NULL COMMENT 'Foreign key that comes from Role'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`dbuserid`, `dbuserfirstname`, `dbuserlastname`, `dbuseremailaddress`, `dbuserphonenumber`, `dbuserhiredate`, `dbuserpassword`, `dbuseraccess`, `dbroleid`) VALUES
(0, 'ONLINE ', 'INTERACTION', 'N/A', 'N/A', '2024-03-20', 'N/A', 0, 3),
(1, 'Lucretia', 'Berendina', 'Berendina@email.com', '(843)-555-5555', '2024-03-20', '$2b$12$JsdWN0jeauxPZUBUFcVtB.VJ2Ozrdj9DQPbpuGB0/dChJlRV0Theq', 1, 1),
(2, 'Aladdin', 'Kevin', 'Kevin@email.com', '(843)-555-5555', '2024-03-20', '$2b$12$qRBhuVkoV3e8UkaucjNVieSESHJvidGUL0E/tknef5QDXzdX8yQtS', 1, 3),
(10, 'Trefor', 'Lando', 'Lando@email.com', '(843)-555-5555', '2024-03-20', '$2b$12$0gAWdF6TYS4HZERiesebO.asGKLm56PnV2MaP3czNGSnaknjAJaG6', 0, 3),
(11, 'Joe', 'John', 'John@email.com', '(555)-555-5555', '2024-03-21', '$2b$12$TsFD8hGQq5IZvzih4oq89e/Nztba6LKYOMkqkkEadNB9Q5jUI94KW', 0, 3),
(12, 'Admin', 'User', 'Admin@email.com', '(123)-555-5555', '2024-03-20', '$2b$12$sFfEh.2QgpFbv4xIYVQBO.QAs1Ts3Xqz9XPzGa1kciGdG9ZYmaYoO', 1, 1),
(13, 'Tre', 'Mill', 'MillerT@email.com', '(843)-555-5555', '2024-03-25', '$2b$12$ODIei/Z8EvtGcLj.q1hLbuolUoMosw.hEL709uDexcWIv6wdZLKJy', 0, 2),
(16, 'user', 'user', 'user@user.com', '(123)-321-5555', '2024-03-31', '$2b$12$uhJkTUhFlqZ0u2g9512m8eWbvI0PBAGDUMfyjTvzmXP2QVWWaUSa.', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Player`
--
ALTER TABLE `Player`
  ADD PRIMARY KEY (`dbplayerid`),
  ADD KEY `player_FK_1` (`dbrewardid`);

--
-- Indexes for table `Product`
--
ALTER TABLE `Product`
  ADD PRIMARY KEY (`dbproductid`);

--
-- Indexes for table `Purchase`
--
ALTER TABLE `Purchase`
  ADD PRIMARY KEY (`dbpurchaseid`),
  ADD KEY `purchase_FK_1` (`dbplayerid`),
  ADD KEY `purchase_FK_2` (`dbuserid`);

--
-- Indexes for table `PurchaseDetail`
--
ALTER TABLE `PurchaseDetail`
  ADD PRIMARY KEY (`dbpurchasedetailid`),
  ADD KEY `purchasedetail_FK_1` (`dbpurchaseid`),
  ADD KEY `purchasedetail_FK_2` (`dbproductid`);

--
-- Indexes for table `Reservation`
--
ALTER TABLE `Reservation`
  ADD PRIMARY KEY (`dbreservationid`),
  ADD KEY `reservation_FK_1` (`dbplayerid`),
  ADD KEY `reservation_FK_2` (`dbuserid`);

--
-- Indexes for table `Reward`
--
ALTER TABLE `Reward`
  ADD PRIMARY KEY (`dbrewardid`);

--
-- Indexes for table `Role`
--
ALTER TABLE `Role`
  ADD PRIMARY KEY (`dbroleid`);

--
-- Indexes for table `Status`
--
ALTER TABLE `Status`
  ADD PRIMARY KEY (`dbstatusid`),
  ADD KEY `status_FK_1` (`dbpurchasedetailid`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`dbuserid`),
  ADD KEY `user_FK_1` (`dbroleid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Player`
--
ALTER TABLE `Player`
  MODIFY `dbplayerid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `Product`
--
ALTER TABLE `Product`
  MODIFY `dbproductid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `Purchase`
--
ALTER TABLE `Purchase`
  MODIFY `dbpurchaseid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `PurchaseDetail`
--
ALTER TABLE `PurchaseDetail`
  MODIFY `dbpurchasedetailid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `Reservation`
--
ALTER TABLE `Reservation`
  MODIFY `dbreservationid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `Reward`
--
ALTER TABLE `Reward`
  MODIFY `dbrewardid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `Role`
--
ALTER TABLE `Role`
  MODIFY `dbroleid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Status`
--
ALTER TABLE `Status`
  MODIFY `dbstatusid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `dbuserid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key', AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Player`
--
ALTER TABLE `Player`
  ADD CONSTRAINT `player_FK_1` FOREIGN KEY (`dbrewardid`) REFERENCES `Reward` (`dbrewardid`);

--
-- Constraints for table `Purchase`
--
ALTER TABLE `Purchase`
  ADD CONSTRAINT `purchase_FK_1` FOREIGN KEY (`dbplayerid`) REFERENCES `Player` (`dbplayerid`),
  ADD CONSTRAINT `purchase_FK_2` FOREIGN KEY (`dbuserid`) REFERENCES `User` (`dbuserid`);

--
-- Constraints for table `PurchaseDetail`
--
ALTER TABLE `PurchaseDetail`
  ADD CONSTRAINT `purchasedetail_FK_1` FOREIGN KEY (`dbpurchaseid`) REFERENCES `Purchase` (`dbpurchaseid`),
  ADD CONSTRAINT `purchasedetail_FK_2` FOREIGN KEY (`dbproductid`) REFERENCES `Product` (`dbproductid`);

--
-- Constraints for table `Reservation`
--
ALTER TABLE `Reservation`
  ADD CONSTRAINT `reservation_FK_1` FOREIGN KEY (`dbplayerid`) REFERENCES `Player` (`dbplayerid`),
  ADD CONSTRAINT `reservation_FK_2` FOREIGN KEY (`dbuserid`) REFERENCES `User` (`dbuserid`);

--
-- Constraints for table `Status`
--
ALTER TABLE `Status`
  ADD CONSTRAINT `status_FK_1` FOREIGN KEY (`dbpurchasedetailid`) REFERENCES `PurchaseDetail` (`dbpurchasedetailid`);

--
-- Constraints for table `User`
--
ALTER TABLE `User`
  ADD CONSTRAINT `user_FK_1` FOREIGN KEY (`dbroleid`) REFERENCES `Role` (`dbroleid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
